# Interoperability

- Use of R and Python chunks with the **knitr** package and RStudio/R markdown

- Use of R package **reticulate** to run Python from R with automatic reflection of objects


